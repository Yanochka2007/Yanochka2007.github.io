import { RouterProvider } from "react-router";
import { router } from "./routes";
import { OrderProvider } from "./context/OrderContext";
import { AuthProvider } from "./context/AuthContext";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  return (
    <AuthProvider>
      <OrderProvider>
        <RouterProvider router={router} />
        <Toaster />
      </OrderProvider>
    </AuthProvider>
  );
}