import { useOrders } from '../context/OrderContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export function Kitchen() {
  const { orders, updateOrderStatus } = useOrders();

  const activeOrders = orders.filter(
    (order) => order.status === 'new' || order.status === 'preparing'
  );

  const sortedOrders = [...activeOrders].sort((a, b) => {
    if (a.status === 'preparing' && b.status === 'new') return -1;
    if (a.status === 'new' && b.status === 'preparing') return 1;
    return a.createdAt.getTime() - b.createdAt.getTime();
  });

  const handleStartCooking = (orderId: string) => {
    updateOrderStatus(orderId, 'preparing');
    toast.success('Заказ принят в работу');
  };

  const handleMarkReady = (orderId: string) => {
    updateOrderStatus(orderId, 'ready');
    toast.success('Заказ готов к подаче');
  };

  const getTimeSinceOrder = (createdAt: Date) => {
    const minutes = Math.floor((Date.now() - createdAt.getTime()) / 60000);
    if (minutes < 1) return 'только что';
    if (minutes === 1) return '1 минута';
    if (minutes < 5) return `${minutes} минуты`;
    return `${minutes} минут`;
  };

  const isUrgent = (createdAt: Date) => {
    const minutes = Math.floor((Date.now() - createdAt.getTime()) / 60000);
    return minutes > 15;
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h2 className="text-3xl font-bold">Кухня</h2>
        <div className="flex gap-5 items-center">
          <div className="flex items-center gap-2">
            <div className="size-4 bg-blue-600 rounded-full"></div>
            <span className="text-base">Новый заказ</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-4 bg-yellow-600 rounded-full"></div>
            <span className="text-base">В работе</span>
          </div>
          <div className="flex items-center gap-2">
            <AlertCircle className="size-4 text-red-600" />
            <span className="text-base">Срочно (&gt;15 мин)</span>
          </div>
        </div>
      </div>

      {sortedOrders.length === 0 ? (
        <div className="text-center text-gray-500 py-16">
          <CheckCircle className="size-20 mx-auto mb-4 text-gray-300" />
          <p className="text-2xl">Нет активных заказов</p>
          <p className="text-base mt-2">Все заказы выполнены</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {sortedOrders.map((order) => {
            const urgent = isUrgent(order.createdAt);
            return (
              <Card
                key={order.id}
                className={`hover:shadow-lg transition-all ${
                  urgent ? 'border-2 border-red-500 animate-pulse' : ''
                }`}
              >
                <CardHeader>
                  <CardTitle className="flex justify-between items-start">
                    <div>
                      <div className="text-3xl font-bold">Стол {order.tableNumber}</div>
                      <div className="text-base text-gray-500 font-normal flex items-center gap-2 mt-1">
                        <Clock className="size-4" />
                        {getTimeSinceOrder(order.createdAt)}
                        {urgent && (
                          <AlertCircle className="size-4 text-red-600 animate-pulse" />
                        )}
                      </div>
                    </div>
                    <Badge
                      className={`text-base px-3 ${
                        order.status === 'new' ? 'bg-blue-600' : 'bg-yellow-600'
                      }`}
                    >
                      {order.status === 'new' ? 'Новый' : 'Готовится'}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      {order.items.map((item, idx) => (
                        <div key={idx}>
                          <div className="flex justify-between items-start">
                            <span className="font-medium text-lg">
                              {item.menuItem.name}
                            </span>
                            <Badge variant="outline" className="ml-2 text-base px-2">
                              x{item.quantity}
                            </Badge>
                          </div>
                          {item.notes && (
                            <div className="text-base text-gray-600 mt-1 italic">
                              → {item.notes}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    <div className="pt-3 border-t">
                      {order.status === 'new' ? (
                        <Button
                          onClick={() => handleStartCooking(order.id)}
                          className="w-full bg-yellow-600 hover:bg-yellow-700 h-12 text-base active:scale-95"
                          size="lg"
                        >
                          <Clock className="size-5 mr-2" />
                          Начать готовить
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleMarkReady(order.id)}
                          className="w-full bg-green-600 hover:bg-green-700 h-12 text-base active:scale-95"
                          size="lg"
                        >
                          <CheckCircle className="size-5 mr-2" />
                          Заказ готов
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
