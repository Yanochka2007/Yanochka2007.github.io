import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { ChefHat, Loader2 } from 'lucide-react';

export function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, user } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const success = await login(username, password);
      if (success) {
        const role = username;
        if (role === 'kitchen') {
          navigate('/kitchen');
        } else if (role === 'admin') {
          navigate('/menu');
        } else {
          navigate('/');
        }
      } else {
        setError('Неверное имя пользователя или пароль');
      }
    } catch (err) {
      setError('Произошла ошибка при входе');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 to-orange-100 p-6">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center pb-6">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-orange-100 rounded-full">
              <ChefHat className="size-16 text-orange-600" />
            </div>
          </div>
          <CardTitle className="text-3xl mb-2">Вход в систему</CardTitle>
          <CardDescription className="text-lg">
            Введите свои учетные данные для доступа к системе управления рестораном
          </CardDescription>
        </CardHeader>
        <CardContent className="px-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-base">Имя пользователя</Label>
              <Input
                id="username"
                type="text"
                placeholder="Введите имя пользователя"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                disabled={loading}
                className="h-12 text-base"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-base">Пароль</Label>
              <Input
                id="password"
                type="password"
                placeholder="Введите пароль"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={loading}
                className="h-12 text-base"
              />
            </div>
            {error && (
              <Alert variant="destructive" className="py-3">
                <AlertDescription className="text-base">{error}</AlertDescription>
              </Alert>
            )}
            <Button type="submit" className="w-full h-12 text-base" disabled={loading} size="lg">
              {loading ? (
                <>
                  <Loader2 className="mr-2 size-5 animate-spin" />
                  Вход...
                </>
              ) : (
                'Войти'
              )}
            </Button>
          </form>
          <div className="mt-6 p-5 bg-gray-50 rounded-lg">
            <p className="text-base font-semibold mb-3">Демо учетные данные:</p>
            <div className="space-y-3">
              <div className="p-3 bg-white rounded-lg border border-gray-200">
                <p className="font-bold text-gray-900">Официант</p>
                <p className="text-gray-600 text-sm mt-1">Логин: waiter / waiter123</p>
                <p className="text-gray-500 text-sm mt-1">Доступ: Столы, Заказы</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-gray-200">
                <p className="font-bold text-gray-900">Повар</p>
                <p className="text-gray-600 text-sm mt-1">Логин: kitchen / kitchen123</p>
                <p className="text-gray-500 text-sm mt-1">Доступ: Кухня</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-gray-200">
                <p className="font-bold text-gray-900">Администратор</p>
                <p className="text-gray-600 text-sm mt-1">Логин: admin / admin123</p>
                <p className="text-gray-500 text-sm mt-1">Доступ: Меню, Пользователи</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
