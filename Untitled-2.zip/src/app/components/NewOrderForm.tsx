import { useState } from 'react';
import { Plus, Minus, Trash2 } from 'lucide-react';
import { useOrders, MenuItem, OrderItem } from '../context/OrderContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent } from './ui/card';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface NewOrderFormProps {
  tableNumber: number;
  onSuccess: () => void;
}

export function NewOrderForm({ tableNumber, onSuccess }: NewOrderFormProps) {
  const { menuItems, addOrder } = useOrders();
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', ...new Set(menuItems.map((item) => item.category))];

  const filteredMenuItems =
    selectedCategory === 'all'
      ? menuItems
      : menuItems.filter((item) => item.category === selectedCategory);

  const addMenuItem = (menuItem: MenuItem) => {
    setOrderItems((prev) => {
      const existingItem = prev.find(
        (item) => item.menuItem.id === menuItem.id
      );
      if (existingItem) {
        return prev.map((item) =>
          item.menuItem.id === menuItem.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { menuItem, quantity: 1 }];
    });
  };

  const updateQuantity = (menuItemId: string, delta: number) => {
    setOrderItems((prev) =>
      prev
        .map((item) =>
          item.menuItem.id === menuItemId
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeItem = (menuItemId: string) => {
    setOrderItems((prev) =>
      prev.filter((item) => item.menuItem.id !== menuItemId)
    );
  };

  const updateNotes = (menuItemId: string, notes: string) => {
    setOrderItems((prev) =>
      prev.map((item) =>
        item.menuItem.id === menuItemId ? { ...item, notes } : item
      )
    );
  };

  const calculateTotal = () => {
    return orderItems.reduce(
      (sum, item) => sum + item.menuItem.price * item.quantity,
      0
    );
  };

  const handleSubmit = () => {
    if (orderItems.length === 0) {
      toast.error('Добавьте блюда в заказ');
      return;
    }

    addOrder({
      tableNumber,
      items: orderItems,
      status: 'new',
      total: calculateTotal(),
    });

    toast.success('Заказ успешно создан');
    setOrderItems([]);
    onSuccess();
  };

  return (
    <div className="grid grid-cols-2 gap-6">
      <div>
        <div className="mb-4">
          <Label className="text-base">Категория</Label>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="h-11 text-base mt-2">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="text-base">
              <SelectItem value="all">Все категории</SelectItem>
              {categories
                .filter((cat) => cat !== 'all')
                .map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2 max-h-[500px] overflow-y-auto">
          {filteredMenuItems.map((item) => (
            <Card
              key={item.id}
              className="cursor-pointer hover:bg-gray-50 active:scale-95 transition-all"
              onClick={() => addMenuItem(item)}
            >
              <CardContent className="p-3">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-medium text-base">{item.name}</div>
                    <div className="text-sm text-gray-500">{item.category}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-base">{item.price} ₽</span>
                    <Plus className="size-4 text-gray-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-4">Заказ - Стол {tableNumber}</h3>
        {orderItems.length === 0 ? (
          <div className="text-center text-gray-500 py-12">
            Выберите блюда из меню
          </div>
        ) : (
          <>
            <div className="space-y-3 max-h-[400px] overflow-y-auto mb-4">
              {orderItems.map((item) => (
                <Card key={item.menuItem.id}>
                  <CardContent className="p-3">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <div className="font-medium text-base">{item.menuItem.name}</div>
                        <div className="text-sm text-gray-500">
                          {item.menuItem.price} ₽
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeItem(item.menuItem.id)}
                      >
                        <Trash2 className="size-4 text-red-500" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-2 mb-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => updateQuantity(item.menuItem.id, -1)}
                        className="h-9 w-9 p-0"
                      >
                        <Minus className="size-4" />
                      </Button>
                      <span className="w-12 text-center font-medium text-base">
                        {item.quantity}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => updateQuantity(item.menuItem.id, 1)}
                        className="h-9 w-9 p-0"
                      >
                        <Plus className="size-4" />
                      </Button>
                      <span className="ml-auto font-semibold text-base">
                        {item.menuItem.price * item.quantity} ₽
                      </span>
                    </div>
                    <Textarea
                      placeholder="Комментарий к блюду..."
                      value={item.notes || ''}
                      onChange={(e) => updateNotes(item.menuItem.id, e.target.value)}
                      className="text-sm"
                      rows={2}
                    />
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="border-t pt-4 space-y-4">
              <div className="flex justify-between items-center text-xl font-bold">
                <span>Итого:</span>
                <span>{calculateTotal()} ₽</span>
              </div>
              <Button onClick={handleSubmit} className="w-full h-12 active:scale-95" size="lg">
                Создать заказ
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
