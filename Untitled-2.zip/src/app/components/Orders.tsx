import { useState } from 'react';
import { Clock, CheckCircle, XCircle } from 'lucide-react';
import { useOrders, OrderStatus } from '../context/OrderContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner';

export function Orders() {
  const { orders, updateOrderStatus } = useOrders();
  const [filter, setFilter] = useState<OrderStatus | 'all'>('all');

  const filteredOrders =
    filter === 'all' ? orders : orders.filter((order) => order.status === filter);

  const sortedOrders = [...filteredOrders].sort(
    (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
  );

  const getStatusBadgeVariant = (status: OrderStatus) => {
    switch (status) {
      case 'new':
        return 'default';
      case 'preparing':
        return 'secondary';
      case 'ready':
        return 'outline';
      case 'delivered':
        return 'outline';
      default:
        return 'default';
    }
  };

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'new':
        return 'bg-blue-600';
      case 'preparing':
        return 'bg-yellow-600';
      case 'ready':
        return 'bg-green-600';
      case 'delivered':
        return 'bg-gray-600';
      default:
        return 'bg-gray-600';
    }
  };

  const getStatusLabel = (status: OrderStatus) => {
    switch (status) {
      case 'new':
        return 'Новый';
      case 'preparing':
        return 'Готовится';
      case 'ready':
        return 'Готов';
      case 'delivered':
        return 'Доставлен';
      default:
        return status;
    }
  };

  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    updateOrderStatus(orderId, newStatus);
    toast.success(`Статус заказа изменен на "${getStatusLabel(newStatus)}"`);
  };

  const getOrderStats = () => {
    return {
      all: orders.length,
      new: orders.filter((o) => o.status === 'new').length,
      preparing: orders.filter((o) => o.status === 'preparing').length,
      ready: orders.filter((o) => o.status === 'ready').length,
      delivered: orders.filter((o) => o.status === 'delivered').length,
    };
  };

  const stats = getOrderStats();

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">Заказы</h2>
      </div>

      <Tabs value={filter} onValueChange={(v) => setFilter(v as OrderStatus | 'all')}>
        <TabsList className="mb-6 h-12">
          <TabsTrigger value="all" className="text-base">Все ({stats.all})</TabsTrigger>
          <TabsTrigger value="new" className="text-base">Новые ({stats.new})</TabsTrigger>
          <TabsTrigger value="preparing" className="text-base">Готовятся ({stats.preparing})</TabsTrigger>
          <TabsTrigger value="ready" className="text-base">Готовы ({stats.ready})</TabsTrigger>
          <TabsTrigger value="delivered" className="text-base">Доставлены ({stats.delivered})</TabsTrigger>
        </TabsList>

        <TabsContent value={filter}>
          {sortedOrders.length === 0 ? (
            <div className="text-center text-gray-500 py-16">
              <p className="text-xl">Нет заказов в данной категории</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {sortedOrders.map((order) => (
                <Card key={order.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex justify-between items-start">
                      <div>
                        <div className="text-2xl">Стол {order.tableNumber}</div>
                        <div className="text-base text-gray-500 font-normal">
                          {order.createdAt.toLocaleTimeString('ru-RU')}
                        </div>
                      </div>
                      <Badge
                        className={`${getStatusColor(order.status)} text-base px-3`}
                        variant={getStatusBadgeVariant(order.status)}
                      >
                        {getStatusLabel(order.status)}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="space-y-1">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between text-base">
                            <span>
                              {item.menuItem.name} x{item.quantity}
                            </span>
                            <span className="text-gray-600">
                              {item.menuItem.price * item.quantity} ₽
                            </span>
                          </div>
                        ))}
                      </div>

                      {order.items.some((item) => item.notes) && (
                        <div className="pt-2 border-t">
                          <div className="text-base font-medium mb-1">Комментарии:</div>
                          {order.items
                            .filter((item) => item.notes)
                            .map((item, idx) => (
                              <div key={idx} className="text-sm text-gray-600">
                                {item.menuItem.name}: {item.notes}
                              </div>
                            ))}
                        </div>
                      )}

                      <div className="pt-2 border-t flex justify-between items-center font-bold text-lg">
                        <span>Итого:</span>
                        <span>{order.total} ₽</span>
                      </div>

                      <div className="pt-2 border-t space-y-2">
                        {order.status === 'new' && (
                          <Button
                            onClick={() => handleStatusChange(order.id, 'preparing')}
                            className="w-full h-11 active:scale-95"
                            variant="default"
                          >
                            <Clock className="size-4 mr-2" />
                            Начать готовить
                          </Button>
                        )}
                        {order.status === 'preparing' && (
                          <Button
                            onClick={() => handleStatusChange(order.id, 'ready')}
                            className="w-full bg-green-600 hover:bg-green-700 h-11 active:scale-95"
                          >
                            <CheckCircle className="size-4 mr-2" />
                            Заказ готов
                          </Button>
                        )}
                        {order.status === 'ready' && (
                          <Button
                            onClick={() => handleStatusChange(order.id, 'delivered')}
                            className="w-full h-11 active:scale-95"
                            variant="outline"
                          >
                            Доставлено
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
