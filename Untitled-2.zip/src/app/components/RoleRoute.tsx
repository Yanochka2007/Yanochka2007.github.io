import { Navigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { ReactNode } from 'react';

interface RoleRouteProps {
  children: ReactNode;
  allowedRoles: string[];
}

export function RoleRoute({ children, allowedRoles }: RoleRouteProps) {
  const { user } = useAuth();

  if (!user?.role || !allowedRoles.includes(user.role)) {
    // Перенаправляем на главную доступную страницу для роли
    if (user?.role === 'kitchen') {
      return <Navigate to="/kitchen" replace />;
    } else if (user?.role === 'admin') {
      return <Navigate to="/menu" replace />;
    }
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
