import { Outlet, Link, useLocation, useNavigate } from 'react-router';
import { ChefHat, Utensils, ShoppingCart, LayoutGrid, LogOut, User, Users } from 'lucide-react';
import { Button } from './ui/button';
import { cn } from './ui/utils';
import { useAuth } from '../context/AuthContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

export function Root() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const allNavItems = [
    { path: '/', label: 'Столы', icon: LayoutGrid, roles: ['waiter'] },
    { path: '/orders', label: 'Заказы', icon: ShoppingCart, roles: ['waiter'] },
    { path: '/kitchen', label: 'Кухня', icon: ChefHat, roles: ['kitchen'] },
    { path: '/menu', label: 'Меню', icon: Utensils, roles: ['admin'] },
    { path: '/users', label: 'Пользователи', icon: Users, roles: ['admin'] },
  ];

  const navItems = allNavItems.filter(item =>
    user?.role && item.roles.includes(user.role)
  );

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getRoleLabel = (role: string) => {
    const roleLabels: Record<string, string> = {
      waiter: 'Официант',
      kitchen: 'Повар',
      admin: 'Администратор',
    };
    return roleLabels[role] || role;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-10 shadow-sm">
        <div className="px-6 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ChefHat className="size-10 text-orange-600" />
              <h1 className="text-2xl font-bold">Система управления рестораном</h1>
            </div>
            <div className="flex items-center gap-3">
              <nav className="flex gap-2">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive =
                    location.pathname === item.path ||
                    (item.path !== '/' && location.pathname.startsWith(item.path));
                  return (
                    <Link key={item.path} to={item.path}>
                      <Button
                        variant={isActive ? 'default' : 'ghost'}
                        className={cn('gap-2 h-12 px-5 text-base')}
                        size="lg"
                      >
                        <Icon className="size-5" />
                        {item.label}
                      </Button>
                    </Link>
                  );
                })}
              </nav>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="gap-2 h-12 px-4 text-base" size="lg">
                    <User className="size-5" />
                    {user?.name}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64 text-base">
                  <DropdownMenuLabel className="text-base py-3">Мой профиль</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem disabled className="py-3">
                    <User className="mr-2 size-5" />
                    {user?.name}
                  </DropdownMenuItem>
                  <DropdownMenuItem disabled className="py-3">
                    Роль: {user?.role && getRoleLabel(user.role)}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600 py-3">
                    <LogOut className="mr-2 size-5" />
                    Выйти
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>
      <main className="px-6 py-6">
        <Outlet />
      </main>
    </div>
  );
}
