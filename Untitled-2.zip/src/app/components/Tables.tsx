import { useState } from 'react';
import { Users, Plus } from 'lucide-react';
import { useOrders } from '../context/OrderContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { NewOrderForm } from './NewOrderForm';
import { cn } from './ui/utils';

export function Tables() {
  const { tables, orders } = useOrders();
  const [selectedTable, setSelectedTable] = useState<number | null>(null);

  const getTableOrders = (tableNumber: number) => {
    return orders.filter(
      (order) => order.tableNumber === tableNumber && order.status !== 'delivered'
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-green-100 border-green-300 hover:border-green-400';
      case 'occupied':
        return 'bg-orange-100 border-orange-300 hover:border-orange-400';
      case 'reserved':
        return 'bg-blue-100 border-blue-300 hover:border-blue-400';
      default:
        return 'bg-gray-100 border-gray-300';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available':
        return <Badge className="bg-green-600 text-base px-3">Свободен</Badge>;
      case 'occupied':
        return <Badge className="bg-orange-600 text-base px-3">Занят</Badge>;
      case 'reserved':
        return <Badge className="bg-blue-600 text-base px-3">Забронирован</Badge>;
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h2 className="text-3xl font-bold">Столы</h2>
        <div className="flex gap-5">
          <div className="flex items-center gap-2">
            <div className="size-4 bg-green-600 rounded"></div>
            <span className="text-base">Свободен</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-4 bg-orange-600 rounded"></div>
            <span className="text-base">Занят</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="size-4 bg-blue-600 rounded"></div>
            <span className="text-base">Забронирован</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {tables.map((table) => {
          const tableOrders = getTableOrders(table.number);
          return (
            <Dialog
              key={table.number}
              open={selectedTable === table.number}
              onOpenChange={(open) => setSelectedTable(open ? table.number : null)}
            >
              <DialogTrigger asChild>
                <Card
                  className={cn(
                    'cursor-pointer transition-all hover:shadow-lg active:scale-95 border-2',
                    getStatusColor(table.status)
                  )}
                >
                  <CardHeader className="pb-3">
                    <CardTitle className="flex justify-between items-center text-2xl">
                      <span>Стол {table.number}</span>
                      {getStatusBadge(table.status)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Users className="size-5" />
                      <span className="text-lg">{table.seats} мест</span>
                    </div>
                    {tableOrders.length > 0 && (
                      <div className="text-base text-gray-600">
                        Активных заказов: {tableOrders.length}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center justify-between text-2xl">
                    <span>Стол {table.number}</span>
                    {getStatusBadge(table.status)}
                  </DialogTitle>
                </DialogHeader>
                <div>
                  {tableOrders.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-xl font-semibold mb-3">Активные заказы</h3>
                      <div className="space-y-3">
                        {tableOrders.map((order) => (
                          <Card key={order.id}>
                            <CardContent className="pt-4">
                              <div className="flex justify-between items-start mb-2">
                                <span className="text-base text-gray-500">
                                  {order.createdAt.toLocaleTimeString('ru-RU')}
                                </span>
                                <Badge variant="outline" className="text-base">{order.status}</Badge>
                              </div>
                              <div className="space-y-1">
                                {order.items.map((item, idx) => (
                                  <div key={idx} className="text-base">
                                    {item.menuItem.name} x{item.quantity}
                                  </div>
                                ))}
                              </div>
                              <div className="mt-3 pt-3 border-t">
                                <span className="font-semibold text-lg">
                                  Итого: {order.total} ₽
                                </span>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <h3 className="text-xl font-semibold mb-4">Новый заказ</h3>
                    <NewOrderForm
                      tableNumber={table.number}
                      onSuccess={() => setSelectedTable(null)}
                    />
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          );
        })}
      </div>
    </div>
  );
}
