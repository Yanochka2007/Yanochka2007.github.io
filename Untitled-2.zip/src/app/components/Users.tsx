import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { UserPlus, Trash2, User } from 'lucide-react';
import { toast } from 'sonner';

interface UserData {
  id: string;
  username: string;
  name: string;
  role: 'waiter' | 'kitchen' | 'admin';
}

export function Users() {
  const [users, setUsers] = useState<UserData[]>([
    { id: '1', username: 'waiter', name: 'Официант', role: 'waiter' },
    { id: '2', username: 'kitchen', name: 'Повар', role: 'kitchen' },
    { id: '3', username: 'admin', name: 'Администратор', role: 'admin' },
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    name: '',
    role: 'waiter' as 'waiter' | 'kitchen' | 'admin',
  });

  const handleAddUser = () => {
    if (!newUser.username || !newUser.password || !newUser.name) {
      toast.error('Заполните все поля');
      return;
    }

    const userExists = users.some(u => u.username === newUser.username);
    if (userExists) {
      toast.error('Пользователь с таким логином уже существует');
      return;
    }

    const user: UserData = {
      id: Date.now().toString(),
      username: newUser.username,
      name: newUser.name,
      role: newUser.role,
    };

    setUsers([...users, user]);
    toast.success(`Пользователь ${newUser.name} успешно добавлен`);

    setNewUser({
      username: '',
      password: '',
      name: '',
      role: 'waiter',
    });
    setIsDialogOpen(false);
  };

  const handleDeleteUser = (id: string) => {
    const user = users.find(u => u.id === id);
    if (user?.username === 'admin') {
      toast.error('Невозможно удалить главного администратора');
      return;
    }

    setUsers(users.filter(u => u.id !== id));
    toast.success('Пользователь удален');
  };

  const getRoleBadge = (role: string) => {
    const roleConfig = {
      waiter: { label: 'Официант', variant: 'default' as const },
      kitchen: { label: 'Повар', variant: 'secondary' as const },
      admin: { label: 'Администратор', variant: 'destructive' as const },
    };
    const config = roleConfig[role as keyof typeof roleConfig];
    return <Badge variant={config.variant} className="text-sm px-2">{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Управление пользователями</h1>
          <p className="text-gray-600 mt-1 text-base">Добавляйте и удаляйте пользователей системы</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 h-12 px-5" size="lg">
              <UserPlus className="size-5" />
              Добавить пользователя
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-2xl">Добавить нового пользователя</DialogTitle>
              <DialogDescription className="text-base">
                Заполните данные для создания нового пользователя
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-base">Имя пользователя</Label>
                <Input
                  id="name"
                  placeholder="Иван Иванов"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  className="h-11 text-base"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username" className="text-base">Логин</Label>
                <Input
                  id="username"
                  placeholder="ivan"
                  value={newUser.username}
                  onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                  className="h-11 text-base"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-base">Пароль</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  className="h-11 text-base"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="role" className="text-base">Роль</Label>
                <Select
                  value={newUser.role}
                  onValueChange={(value: 'waiter' | 'kitchen' | 'admin') =>
                    setNewUser({ ...newUser, role: value })
                  }
                >
                  <SelectTrigger className="h-11 text-base">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="text-base">
                    <SelectItem value="waiter">Официант</SelectItem>
                    <SelectItem value="kitchen">Повар</SelectItem>
                    <SelectItem value="admin">Администратор</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="h-11 px-5">
                Отмена
              </Button>
              <Button onClick={handleAddUser} className="h-11 px-5">Добавить</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Список пользователей</CardTitle>
          <CardDescription className="text-base">
            Всего пользователей: {users.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-base">Имя</TableHead>
                <TableHead className="text-base">Логин</TableHead>
                <TableHead className="text-base">Роль</TableHead>
                <TableHead className="w-[100px] text-base">Действия</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <User className="size-5 text-gray-500" />
                      <span className="text-base font-medium">{user.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-sm">{user.username}</TableCell>
                  <TableCell>{getRoleBadge(user.role)}</TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteUser(user.id)}
                      disabled={user.username === 'admin'}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <CardTitle className="text-orange-900 text-xl">Информация о ролях</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-base text-orange-800">
          <p><strong>Официант:</strong> Доступ к управлению столами и заказами</p>
          <p><strong>Повар:</strong> Доступ только к интерфейсу кухни для приготовления блюд</p>
          <p><strong>Администратор:</strong> Доступ к меню и управлению пользователями</p>
        </CardContent>
      </Card>
    </div>
  );
}
