import { createContext, useContext, useState, ReactNode } from 'react';

export type OrderStatus = 'new' | 'preparing' | 'ready' | 'delivered';

export interface MenuItem {
  id: string;
  name: string;
  category: string;
  price: number;
  image?: string;
}

export interface OrderItem {
  menuItem: MenuItem;
  quantity: number;
  notes?: string;
}

export interface Order {
  id: string;
  tableNumber: number;
  items: OrderItem[];
  status: OrderStatus;
  createdAt: Date;
  total: number;
}

export interface Table {
  number: number;
  seats: number;
  status: 'available' | 'occupied' | 'reserved';
  currentOrderId?: string;
}

interface OrderContextType {
  orders: Order[];
  tables: Table[];
  menuItems: MenuItem[];
  addOrder: (order: Omit<Order, 'id' | 'createdAt'>) => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  updateTableStatus: (tableNumber: number, status: Table['status'], orderId?: string) => void;
  getOrdersByTable: (tableNumber: number) => Order[];
  getActiveOrders: () => Order[];
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

const initialMenuItems: MenuItem[] = [
  { id: '1', name: 'Борщ', category: 'Супы', price: 350 },
  { id: '2', name: 'Солянка', category: 'Супы', price: 400 },
  { id: '3', name: 'Цезарь с курицей', category: 'Салаты', price: 450 },
  { id: '4', name: 'Греческий салат', category: 'Салаты', price: 380 },
  { id: '5', name: 'Стейк из говядины', category: 'Горячее', price: 1200 },
  { id: '6', name: 'Семга на гриле', category: 'Горячее', price: 950 },
  { id: '7', name: 'Паста Карбонара', category: 'Горячее', price: 550 },
  { id: '8', name: 'Пицца Маргарита', category: 'Горячее', price: 650 },
  { id: '9', name: 'Наполеон', category: 'Десерты', price: 280 },
  { id: '10', name: 'Тирамису', category: 'Десерты', price: 320 },
  { id: '11', name: 'Эспрессо', category: 'Напитки', price: 150 },
  { id: '12', name: 'Капучино', category: 'Напитки', price: 200 },
  { id: '13', name: 'Морс клюквенный', category: 'Напитки', price: 180 },
  { id: '14', name: 'Сок апельсиновый', category: 'Напитки', price: 200 },
];

const initialTables: Table[] = Array.from({ length: 12 }, (_, i) => ({
  number: i + 1,
  seats: [2, 4, 4, 6, 2, 4, 4, 6, 8, 4, 2, 4][i],
  status: 'available',
}));

export function OrderProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [tables, setTables] = useState<Table[]>(initialTables);
  const menuItems = initialMenuItems;

  const addOrder = (order: Omit<Order, 'id' | 'createdAt'>) => {
    const newOrder: Order = {
      ...order,
      id: `order-${Date.now()}`,
      createdAt: new Date(),
    };
    setOrders((prev) => [...prev, newOrder]);
    updateTableStatus(order.tableNumber, 'occupied', newOrder.id);
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id === orderId) {
          if (status === 'delivered') {
            // Освобождаем стол при доставке заказа
            updateTableStatus(order.tableNumber, 'available');
          }
          return { ...order, status };
        }
        return order;
      })
    );
  };

  const updateTableStatus = (
    tableNumber: number,
    status: Table['status'],
    orderId?: string
  ) => {
    setTables((prev) =>
      prev.map((table) =>
        table.number === tableNumber
          ? { ...table, status, currentOrderId: orderId }
          : table
      )
    );
  };

  const getOrdersByTable = (tableNumber: number) => {
    return orders.filter((order) => order.tableNumber === tableNumber);
  };

  const getActiveOrders = () => {
    return orders.filter((order) => order.status !== 'delivered');
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        tables,
        menuItems,
        addOrder,
        updateOrderStatus,
        updateTableStatus,
        getOrdersByTable,
        getActiveOrders,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
}

export function useOrders() {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within OrderProvider');
  }
  return context;
}
