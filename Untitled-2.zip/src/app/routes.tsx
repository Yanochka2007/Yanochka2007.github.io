import { createBrowserRouter, Navigate } from "react-router";
import { Root } from "./components/Root";
import { Orders } from "./components/Orders";
import { Menu } from "./components/Menu";
import { Kitchen } from "./components/Kitchen";
import { Tables } from "./components/Tables";
import { Users } from "./components/Users";
import { Login } from "./components/Login";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { RoleRoute } from "./components/RoleRoute";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/",
    element: <ProtectedRoute><Root /></ProtectedRoute>,
    children: [
      {
        index: true,
        element: <RoleRoute allowedRoles={['waiter']}><Tables /></RoleRoute>
      },
      {
        path: "orders",
        element: <RoleRoute allowedRoles={['waiter']}><Orders /></RoleRoute>
      },
      {
        path: "kitchen",
        element: <RoleRoute allowedRoles={['kitchen']}><Kitchen /></RoleRoute>
      },
      {
        path: "menu",
        element: <RoleRoute allowedRoles={['admin']}><Menu /></RoleRoute>
      },
      {
        path: "users",
        element: <RoleRoute allowedRoles={['admin']}><Users /></RoleRoute>
      },
    ],
  },
]);
